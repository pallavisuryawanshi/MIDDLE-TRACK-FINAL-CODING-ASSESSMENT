const express = require('express');
const parser=require('body-parser');
const mysql=require('mysql');
const{truncate}= require('fs');
const{request,resoonse}= require('express');
const app=express();
app.use(parser.json());

const conn = mysql.createConnection({
    host: 'localhost',
    ssl :{
        rejectUnauthorized:false
    },
    user: 'root',
    password: 'Admin@123',
    database: 'world'
    //insecureAuth:true
});

conn.connect((err) =>{
    if(err) 
        throw err;
    console.log(' Connected to database......');
});

app.get('/bajaj/persons',(request,response)=>{
    let sql ='select * from person';
    conn.query(sql,(err,result)=>{
        if(err)
            throw err;
        else{
             console.log(result);
        response.send(result);  
        }
    });
    });

    app.get('/bajaj/persons/{id}',(request,response)=>{ 
        let sql ='select * from person where id=' +request.params.id;

        conn.query(sql,(err,result)=>{
            if(err)
                throw err;
            else{
                console.log(result);
                response.send(result);

            }
            
        });
    });
    
    

    app.post('',(request,response)=>{
        let data = {id:request.body.id,name: request.body.name, address:request.body.address,mobile:request.body.mobile,
             email:request.body.email, age:request.body.age, dateofbirth:request.body.dateofbirth};
        let sql ='insert into person SET ?';//json Object field value
        let query = conn.query(sql,data,(err,result)=>{
            if(err)
               throw err;
             else
                console.log('person details inserted with and an id' +result.insertId );
                response.send('person details inserted sucessfully \n your person id is:'+result.insecureAuth);    
        });
    });


    app.put('/bajaj/persons/{id}',(request,response)=>{
        let data = {id:request.body.id,name: request.body.name, address:request.body.address,mobile:request.body.mobile,
            email:request.body.email, age:request.body.age, dateofbirth:request.body.dateofbirth};
        let sql='update person set SET ?';
        let query=con.query(sql,(err,result)=>{
            if(err)
                throw err;
            else if(result.affectedRows>0)
                response.send('Record Updated Successfully....');
    
        });
    
    });
    app.delete('/bajaj/persons/{id}',(request,response)=>{
        let sql="delete from person where id="+request.params.id;
        letquery=con.query(sql,(err,result)=>{
            if(err)
                throw err;
            else
            response.send('Record Got Deleted Successfully....');
        });
    
    });




    app.listen(3000,()=>{
        console.log('Server Started on port 3000......');
    });