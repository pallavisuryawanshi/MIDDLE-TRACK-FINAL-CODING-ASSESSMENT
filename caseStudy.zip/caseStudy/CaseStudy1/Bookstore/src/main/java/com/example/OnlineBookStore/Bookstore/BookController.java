package com.example.OnlineBookStore.Bookstore;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.PutMapping;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestMethod;
import org.springframework.web.bind.annotation.RestController;

import java.util.List;
@RestController
public class BookController {
	@Autowired  BookService service;
	@GetMapping ("/bookstore/books")
	public List<Book> getAllBookDetails()
	{
     return service.getBookDetails();
	}
	
	@PostMapping ("/bookstore/books")
	public Book AddBook( @RequestBody Book p) {
		return service.AddBookDetails(p);
	}
	@PutMapping("/bookstore/books{id}" )
	public Book EditBook(@RequestBody Book p, @PathVariable("id") Integer id) {
		return service.EditBookDetails(p, id);
		
	}
	@RequestMapping(method = RequestMethod.DELETE,path="/bookstore/books/{id}")
	public String DeleteBook(@PathVariable("id")Integer id) {
		
		 service.DeleteBookDetails(id);
		 return "Book Details are removed Succesfully";
	}
	
	@RequestMapping(method = RequestMethod.GET,path= "/bookstore/books/{id}")
	public Book GetBookDetails(@PathVariable("id") Integer id)
	{ 
		service.RetrieveBookDetails(id);
	}  
}
