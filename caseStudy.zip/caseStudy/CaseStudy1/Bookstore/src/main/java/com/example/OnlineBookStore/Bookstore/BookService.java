package com.example.OnlineBookStore.Bookstore;

import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

public class BookService {
	@Autowired BookRepository repo;
	public List<Book> getBookDetails(){
	return repo.findAll();
	}

	
	public Book AddBookDetails(Book p) {
		return repo.save(p);
	}
	
	public Book EditBookDetails(Book p,  Integer id) {
		return repo.save(p);
	}
	
	public void DeleteBookDetails( Integer id) {
		repo.deleteById(id);
		
	}
	public Book RetrieveBookDetails(Integer id) {
		return repo.findById(id).get();
		
	}
}
